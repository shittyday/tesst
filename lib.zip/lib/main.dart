import 'package:flutter/material.dart';
import 'package:flutter_test_app/app_routes.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  void onFirstPage() {
    Navigator.pushNamed(context, '/first');
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      onGenerateRoute: AppRoutes.onGenerateRoute,
      theme: ThemeData(brightness: Brightness.dark),
      home: Scaffold(
        body: const Center(child: Text('Hello Demo World!')),
        floatingActionButton: FloatingActionButton.extended(label: const Text('На первый экран'), onPressed: () => onFirstPage),
      ),
    );
  }
}
