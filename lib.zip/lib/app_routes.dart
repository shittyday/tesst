import 'package:flutter/material.dart';
import 'package:flutter_test_app/first/first_change_notifier.dart';
import 'package:flutter_test_app/first/first_screen.dart';
import 'package:flutter_test_app/second/second_screen.dart';
import 'package:provider/provider.dart';

abstract class AppRoutes {
  static Route<dynamic>? onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/first':
        return MaterialPageRoute(builder: (_) {
          return ListenableProvider(
            create: (_) => FirstChangeNotifier(),
            dispose: (context, value) => value.dispose(),
            child: const FirstScreen(),
          );
        });
      case '/second':
        return MaterialPageRoute(builder: (_) => SecondScreen(map: settings.arguments as Map));
    }
    return null;
  }
}
