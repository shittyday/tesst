import 'dart:developer' as dev;
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test_app/first/first_change_notifier.dart';
import 'package:flutter_test_app/first/first_screen_body.dart';
import 'package:provider/provider.dart';

class FirstScreen extends StatefulWidget {
  const FirstScreen({super.key});

  @override
  State<FirstScreen> createState() => _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  @override
  Widget build(BuildContext context) {
    final notifier = context.read<FirstChangeNotifier>();
    return SafeArea(
      top: false,
      child: Scaffold(
          resizeToAvoidBottomInset: true,
          appBar: AppBar(
            title: const Text('First Screen'),
          ),
          floatingActionButton: FloatingActionButton(onPressed: () {
            dev.log(notifier.ints.join(','));
            notifier.addInt(Random().nextInt(100));
          }),
          body: FirstScreenBody(ints: notifier.ints)),
    );
  }
}
