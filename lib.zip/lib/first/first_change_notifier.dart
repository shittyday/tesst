import 'package:flutter/material.dart';

class FirstChangeNotifier extends ChangeNotifier {
  // ignore: prefer_final_fields
  List<int> _ints = [];

  List<int> get ints => _ints;

  addInt(int value) {
    _ints.add(value);
    notifyListeners();
  }
}
