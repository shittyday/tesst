import 'dart:developer';

import 'package:flutter/material.dart';

class FirstScreenBody extends StatelessWidget {
  final List<int> ints;
  const FirstScreenBody({super.key, required this.ints});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        ListView.builder(
          padding: kMaterialListPadding,
          itemCount: ints.length,
          itemBuilder: (context, index) {
            return Text(ints[index].toString());
          },
        ),
        ElevatedButton(
          onPressed: () async {
            try {
              final map = {'value': 3};
              await Navigator.pushNamed(context, '/second', arguments: map);
              log('$map');
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Страница не найдена')));
            }
          },
          child: const Text('Вторая страница'),
        ),
        const SizedBox(height: 20)
      ],
    );
  }
}
