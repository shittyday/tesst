import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test_app/first/first_change_notifier.dart';
import 'package:provider/provider.dart';

class SecondScreen extends StatefulWidget {
  final Map map;

  const SecondScreen({super.key, required this.map});

  @override
  State<SecondScreen> createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  late final int? _int;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Second Screen')),
      body: Column(
        children: [
          Expanded(child: Text(_int.toString())),
          ElevatedButton(
              onPressed: () {
                widget.map['value'] = 1;
              },
              child: const Text('Работа с МАПОЙ')),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: () {
        showModalBottomSheet(
            context: context,
            builder: (context) {
              return LayoutBuilder(
                  builder: (context, constraints) => SizedBox(
                        width: constraints.maxWidth,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(height: 30),
                            const Text('Модальное окно'),
                            SizedBox(
                              height: 30,
                              width: constraints.maxWidth,
                            ),
                            Flexible(child: Text(context.watch<FirstChangeNotifier>().ints.join(','))),
                            const SizedBox(height: 100),
                            ElevatedButton(
                                onPressed: () {
                                  context.read<FirstChangeNotifier>().addInt(Random().nextInt(100));
                                },
                                child: const Text('Добавить еще одно значение')),
                            const SizedBox(height: 100),
                          ],
                        ),
                      ));
            });
      }),
    );
  }
}
